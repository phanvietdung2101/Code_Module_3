create
    definer = root@`%` procedure TONG_TIEN_XUAT(IN mavtuP int)
begin
    select sum(SLXUAT * DGXUAT)
    from CTPXUAT
    where MAVTU = mavtuP
    group by MAVTU;
end;

