create definer = root@`%` view vw_CTPNHAP_VT_loc as
select `baitapView`.`CTPNHAP`.`SOPN`                                       AS `SOPN`,
       `baitapView`.`CTPNHAP`.`MAVTU`                                      AS `MAVTU`,
       `baitapView`.`CTPNHAP`.`SLNHAP`                                     AS `SLNHAP`,
       `baitapView`.`CTPNHAP`.`DGNHAP`                                     AS `DGNHAP`,
       (`baitapView`.`CTPNHAP`.`SLNHAP` * `baitapView`.`CTPNHAP`.`DGNHAP`) AS `THANH_TIEN_NHAP`
from (`baitapView`.`CTPNHAP`
         join `baitapView`.`VATTU` `V` on ((`baitapView`.`CTPNHAP`.`MAVTU` = `V`.`MAVTU`)))
where (`V`.`DVTINH` = 'BO');

