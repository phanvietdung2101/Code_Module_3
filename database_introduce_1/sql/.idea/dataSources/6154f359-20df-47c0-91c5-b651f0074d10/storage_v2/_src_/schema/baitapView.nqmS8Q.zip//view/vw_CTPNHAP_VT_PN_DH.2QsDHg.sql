create definer = root@`%` view vw_CTPNHAP_VT_PN_DH as
select `baitapView`.`CTPNHAP`.`SOPN`                                       AS `SOPN`,
       `P`.`NGAYNHAP`                                                      AS `NGAYNHAP`,
       `D`.`SODH`                                                          AS `SODH`,
       `D`.`MANHACC`                                                       AS `MANHACC`,
       `baitapView`.`CTPNHAP`.`MAVTU`                                      AS `MAVTU`,
       `V`.`TENVTU`                                                        AS `TENVTU`,
       `baitapView`.`CTPNHAP`.`SLNHAP`                                     AS `SLNHAP`,
       `baitapView`.`CTPNHAP`.`DGNHAP`                                     AS `DGNHAP`,
       (`baitapView`.`CTPNHAP`.`SLNHAP` * `baitapView`.`CTPNHAP`.`DGNHAP`) AS `THANH_TIEN_NHAP`
from (((`baitapView`.`CTPNHAP` join `baitapView`.`VATTU` `V` on ((`baitapView`.`CTPNHAP`.`MAVTU` = `V`.`MAVTU`))) join `baitapView`.`PNHAP` `P` on ((`baitapView`.`CTPNHAP`.`SOPN` = `P`.`SOPN`)))
         join `baitapView`.`DONDH` `D` on ((`P`.`SODH` = `D`.`SODH`)));

