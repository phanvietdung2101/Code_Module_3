create definer = root@`%` view productStatus as
select `demo`.`Products`.`status` AS `status`
from `demo`.`Products`
group by `demo`.`Products`.`status`;

