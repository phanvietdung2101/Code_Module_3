create
    definer = root@`%` procedure addProduct(IN productId int, IN productCode varchar(255), IN productName varchar(255),
                                            IN productPrice double, IN productAmount int,
                                            IN productDescription varchar(255), IN productStatus varchar(255))
begin
    insert into Products value (productId,productCode,productName,productPrice,productAmount,productDescription,productStatus);
end;

