create definer = root@`%` view vw_CTPNHAP as
select `baitapView`.`CTPNHAP`.`SOPN`   AS `SOPN`,
       `baitapView`.`CTPNHAP`.`MAVTU`  AS `MAVTU`,
       `baitapView`.`CTPNHAP`.`SLNHAP` AS `SLNHAP`,
       `baitapView`.`CTPNHAP`.`DGNHAP` AS `DGNHAP`
from `baitapView`.`CTPNHAP`;

