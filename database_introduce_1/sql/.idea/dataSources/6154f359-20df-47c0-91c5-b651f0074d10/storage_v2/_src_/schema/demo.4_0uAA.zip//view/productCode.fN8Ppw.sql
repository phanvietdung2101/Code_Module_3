create definer = root@`%` view productCode as
select `demo`.`Products`.`code` AS `code`
from `demo`.`Products`;

