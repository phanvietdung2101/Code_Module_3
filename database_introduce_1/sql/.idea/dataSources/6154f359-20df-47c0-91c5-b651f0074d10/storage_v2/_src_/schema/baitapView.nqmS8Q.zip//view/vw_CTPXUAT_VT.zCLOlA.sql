create definer = root@`%` view vw_CTPXUAT_VT as
select `baitapView`.`CTPXUAT`.`SOPX`                                       AS `SOPX`,
       `baitapView`.`CTPXUAT`.`MAVTU`                                      AS `MAVTU`,
       `V`.`TENVTU`                                                        AS `TENVTU`,
       `baitapView`.`CTPXUAT`.`SLXUAT`                                     AS `SLXUAT`,
       (`baitapView`.`CTPXUAT`.`SLXUAT` * `baitapView`.`CTPXUAT`.`DGXUAT`) AS `THANH_TIEN_XUAT`
from (`baitapView`.`CTPXUAT`
         join `baitapView`.`VATTU` `V` on ((`baitapView`.`CTPXUAT`.`MAVTU` = `V`.`MAVTU`)));

