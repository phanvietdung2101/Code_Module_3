create definer = root@`%` view vw_CTPXUAT as
select `baitapView`.`CTPXUAT`.`SOPX`                                       AS `SOPX`,
       `baitapView`.`CTPXUAT`.`MAVTU`                                      AS `MAVTU`,
       `baitapView`.`CTPXUAT`.`SLXUAT`                                     AS `SLXUAT`,
       `baitapView`.`CTPXUAT`.`DGXUAT`                                     AS `DGXUAT`,
       (`baitapView`.`CTPXUAT`.`SLXUAT` * `baitapView`.`CTPXUAT`.`DGXUAT`) AS `THANH_TIEN_XUAT`
from `baitapView`.`CTPXUAT`;

