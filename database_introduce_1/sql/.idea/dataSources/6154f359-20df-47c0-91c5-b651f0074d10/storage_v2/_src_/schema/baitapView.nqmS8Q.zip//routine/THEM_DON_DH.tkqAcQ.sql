create
    definer = root@`%` procedure THEM_DON_DH(IN SODH int, IN NGAYDH date, IN MANHACC varchar(255))
begin
    insert into DONDH value (SODH,NGAYDH,MANHACC);
end;

