create
    definer = root@`%` procedure TIM_SO_LUONG_CUOI(IN mavtuP int)
begin
    select SLCUOI from TONKHO where MAVTU =  mavtuP ;
end;

