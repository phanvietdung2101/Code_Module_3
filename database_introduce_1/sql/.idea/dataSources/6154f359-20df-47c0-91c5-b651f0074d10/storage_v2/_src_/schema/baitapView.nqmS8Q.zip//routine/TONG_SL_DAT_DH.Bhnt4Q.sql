create
    definer = root@`%` procedure TONG_SL_DAT_DH(IN so_dh int)
begin
    select sum(SLDAT)
        from CTDONDH
            where SODH = so_dh
    group by SODH;
end;

