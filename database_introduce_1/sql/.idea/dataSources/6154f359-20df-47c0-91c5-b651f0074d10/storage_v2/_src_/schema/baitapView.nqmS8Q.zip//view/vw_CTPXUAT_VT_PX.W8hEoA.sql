create definer = root@`%` view vw_CTPXUAT_VT_PX as
select `baitapView`.`CTPXUAT`.`SOPX`   AS `SOPX`,
       `P`.`TENKH`                     AS `TENKH`,
       `baitapView`.`CTPXUAT`.`MAVTU`  AS `MAVTU`,
       `V`.`TENVTU`                    AS `TENVTU`,
       `baitapView`.`CTPXUAT`.`SLXUAT` AS `SLXUAT`,
       `baitapView`.`CTPXUAT`.`DGXUAT` AS `DGXUAT`
from ((`baitapView`.`CTPXUAT` join `baitapView`.`VATTU` `V` on ((`baitapView`.`CTPXUAT`.`MAVTU` = `V`.`MAVTU`)))
         join `baitapView`.`PXUAT` `P` on ((`baitapView`.`CTPXUAT`.`SOPX` = `P`.`SOPX`)));

