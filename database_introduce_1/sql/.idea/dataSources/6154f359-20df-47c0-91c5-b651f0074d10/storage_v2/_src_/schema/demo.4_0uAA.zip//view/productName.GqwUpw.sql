create definer = root@`%` view productName as
select `demo`.`Products`.`name` AS `name`
from `demo`.`Products`;

