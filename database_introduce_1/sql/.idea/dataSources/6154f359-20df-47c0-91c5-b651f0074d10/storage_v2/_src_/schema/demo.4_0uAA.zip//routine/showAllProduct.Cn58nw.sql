create
    definer = root@`%` procedure showAllProduct()
begin
    select * from Products;
end;

