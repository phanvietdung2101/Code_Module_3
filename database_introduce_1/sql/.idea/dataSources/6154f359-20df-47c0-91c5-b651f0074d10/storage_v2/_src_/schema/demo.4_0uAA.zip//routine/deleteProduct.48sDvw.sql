create
    definer = root@`%` procedure deleteProduct(IN productId int)
begin
    delete from Products
        where id = productId;
end;

