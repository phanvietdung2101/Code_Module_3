create
    definer = root@`%` procedure THEM_CT_DON_DH(IN SODH int, IN MAVTU int, IN SLDAT int)
begin
    insert into CTDONDH value (SODH,MAVTU,SLDAT);
end;

